# skill.mattpocock.prototype

Exact review-only source-file assessment at mattpocock/skills@c55ee46073ed923f86ce59a5eb3b6d895095d1b7:skills/engineering/prototype/SKILL.md. Scanner findings, coverage limits, authority, and dates remain unchanged. This is not a clean-scan declaration, installation approval, runtime authority, or organization admission.
