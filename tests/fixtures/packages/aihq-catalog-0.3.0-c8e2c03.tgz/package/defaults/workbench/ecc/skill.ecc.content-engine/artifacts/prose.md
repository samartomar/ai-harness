# skill.ecc.content-engine

Exact review-only source-file assessment at affaan-m/ECC@5064474d4d762dc9640234a41617cccb79185cec:skills/content-engine/SKILL.md. Scanner findings, coverage limits, authority, and dates remain unchanged. This is not a clean-scan declaration, installation approval, runtime authority, or organization admission.

Curated source roots: `.agents/skills/content-engine`, `skills/content-engine`; the entry is the canonical root's `skills/content-engine/SKILL.md`.
