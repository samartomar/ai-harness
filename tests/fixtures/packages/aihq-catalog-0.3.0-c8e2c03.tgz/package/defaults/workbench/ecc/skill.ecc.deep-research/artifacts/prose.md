# skill.ecc.deep-research

Exact review-only source-file assessment at affaan-m/ECC@5064474d4d762dc9640234a41617cccb79185cec:skills/deep-research/SKILL.md. Scanner findings, coverage limits, authority, and dates remain unchanged. This is not a clean-scan declaration, installation approval, runtime authority, or organization admission.

Curated source roots: `.agents/skills/deep-research`, `skills/deep-research`; the entry is the canonical root's `skills/deep-research/SKILL.md`.
