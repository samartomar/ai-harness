# mcp.ecc.cloudflare-workers-builds

Exact review-only source-file assessment at affaan-m/ECC@5064474d4d762dc9640234a41617cccb79185cec:mcp-configs/mcp-servers.json. Scanner findings, coverage limits, authority, and dates remain unchanged. This is not a clean-scan declaration, installation approval, runtime authority, or organization admission.

Shared declaration files, listed by the curated definition for several components: `mcp-configs/mcp-servers.json`. A finding located in a shared file is stated on every row whose closure holds it.
