# skill.ecc.mcp-server-patterns

Exact review-only source-file assessment at affaan-m/ECC@5064474d4d762dc9640234a41617cccb79185cec:skills/mcp-server-patterns/SKILL.md. Scanner findings, coverage limits, authority, and dates remain unchanged. This is not a clean-scan declaration, installation approval, runtime authority, or organization admission.

Curated source roots: `.agents/skills/mcp-server-patterns`, `skills/mcp-server-patterns`; the entry is the canonical root's `skills/mcp-server-patterns/SKILL.md`.
