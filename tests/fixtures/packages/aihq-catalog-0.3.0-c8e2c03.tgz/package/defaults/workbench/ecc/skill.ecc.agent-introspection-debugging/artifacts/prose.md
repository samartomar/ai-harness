# skill.ecc.agent-introspection-debugging

Exact review-only source-file assessment at affaan-m/ECC@5064474d4d762dc9640234a41617cccb79185cec:skills/agent-introspection-debugging/SKILL.md. Scanner findings, coverage limits, authority, and dates remain unchanged. This is not a clean-scan declaration, installation approval, runtime authority, or organization admission.

Curated source roots: `.agents/skills/agent-introspection-debugging`, `skills/agent-introspection-debugging`; the entry is the canonical root's `skills/agent-introspection-debugging/SKILL.md`.
