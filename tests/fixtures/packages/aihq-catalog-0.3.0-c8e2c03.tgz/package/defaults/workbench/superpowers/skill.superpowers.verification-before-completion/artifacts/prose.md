# skill.superpowers.verification-before-completion

Exact review-only source-file assessment at obra/Superpowers@5bf4e78011075bcfc0dc295f0724994cd123ee71:skills/verification-before-completion/SKILL.md. Scanner findings, coverage limits, authority, and dates remain unchanged. This is not a clean-scan declaration, installation approval, runtime authority, or organization admission.
