neutral default prose
