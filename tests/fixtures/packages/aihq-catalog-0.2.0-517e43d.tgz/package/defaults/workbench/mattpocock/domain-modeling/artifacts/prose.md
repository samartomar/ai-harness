# domain-modeling

Exact source: mattpocock/skills@3cca18b368ae95cdbdebbff572ccafa662551015:skills/engineering/domain-modeling/SKILL.md. This member preserves a bounded source-file assessment, not a clean-scan declaration, installation recipe, or organization approval. Scanner findings remain unresolved.
