Core 0.6.2 agent candidate governance-quality. Scope and Scanner custody are bound by the adjacent profile, closure, and verified report evidence; no organization admission is asserted.
