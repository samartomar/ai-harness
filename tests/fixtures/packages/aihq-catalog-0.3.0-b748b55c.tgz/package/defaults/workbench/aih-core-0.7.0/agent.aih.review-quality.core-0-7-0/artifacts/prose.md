Core 0.7.0 agent candidate review-quality. Scope and Scanner custody are bound by the adjacent profile, closure, and verified report evidence; no organization admission is asserted.
