Core 0.7.0 skill candidate docs-quality. Scope and Scanner custody are bound by the adjacent profile, closure, and verified report evidence; no organization admission is asserted.
