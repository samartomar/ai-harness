Core 0.7.0 mcp candidate code-review-graph. Scope and Scanner custody are bound by the adjacent profile, closure, and verified report evidence; no organization admission is asserted.
